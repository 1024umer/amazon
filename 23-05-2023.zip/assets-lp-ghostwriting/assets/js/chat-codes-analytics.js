
// document.write("<script id='ze-snippet' src='https://static.zdassets.com/ekr/snippet.js?key=728cf506-1a8d-46b2-a131-073f19b5c1b4'> </script>");

function setButtonURL() {
    // zE.activate();
    zE('messenger', 'open');
}


$('.chat').click( function(){
    // zE.activate();
    zE('messenger', 'open');
});

<?php include 'include/header.php';?>


<section class="terms-bnr">
<div class="container">
<div class="row">
<div class="col-sm-12">
<div class="mbnr-left-txt">
<h1 class="wow fadeInUp" data-wow-duration="2s">Thank you</h1>
</div>
</div>
<div class="col-sm-7">

</div>
</div>
</div>
</section>

<?php include 'include/footer.php';?>


</body>


</html>
